# extension_cognigy
REST-Api Extension for cognigy
